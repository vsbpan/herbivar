#' @title Compute Watershed Transform With Grayscale And Color Image Support
#' @description Internal function of \code{clean_leaf()}. A wrapper of \code{watershed()} and \code{threshold()} that handles both grayscale and color images. If available, the blue spectrum of the transformed image is used for thresholding, as blue is a rare color among plats.
#' @param seed an image
#' @param p priority map
#' @param spectrum number of spectrum.
#' @param thr a threshold, either numeric, "kmeans", or "otsu", or string for quantiles.
#' @param approx.res the number of pixels used in threshold approximation. Default is 10000.
#' @param km an integer vector of length two. The first value selects the the boundary rank in increasing means identified by kmeans clustering (defaults to 1, selecting the boundary that separates the two clusters with the lowest mean). The second value selects the k number of clusters to form (defaults to 2). Ignored when not auto-thresholding.
#' @return a pixset
#' @export
watershed2 <- function(seed, p, spectrum, thr = "kmeans", approx.res = 10000, km = c(1L, 2L)){
  ws <- watershed(seed,p)
  if(spectrum == 3){
    ws <- as.cimg(ws[,,,3]) # Blue gray scale works better for leaves because blue is rare
  } else if(spectrum > 1){
    ws <- as.cimg(ws[,,,1])
  }
  ws <- threshold2(ws, thr = thr, approx.res = approx.res, km = km,
                   thr.exact = FALSE, return.thr.only = FALSE)
  return(ws)
}


#' @title Threshold Foreground With Automatic Threshold Selection
#' @description Internal function of \code{clean_leaf()}. Basically acts as a wrapper for \code{threshold()} with added threshold reporting and error handling. When foreground threshold is selected, either manually or automatically, above 100%, the threshold is reduced by 10% recursively up to five times until foreground threshold is less than 100%. Automatically selected threshold by \code{threshold()}that is below 40% maybe too low and is increased by 30% automatically.
#' @param img a cimg object
#' @param fg.thresh a threshold for turning the cimg pixels into a selected pixset. Can be either numeric, a string, "kemans", or "otsu". When set to "kmenas" or "otsu", the threshold is automatically selected by the internal function \code{threshold2()}.
#' @param fg.adjust used to adjust the automatic threshold. If the auto-threshold is at k, the effective threshold will be at \code{fg.adjust} * k.
#' @param approx.res the number of pixels used in threshold approximation. Default is 10000.
#' @param km an integer vector of length two. The first value selects the the boundary rank in increasing means identified by kmeans clustering (defaults to 1, selecting the boundary that separates the two clusters with the lowest mean). The second value selects the k number of clusters to form (defaults to 2). Ignored when not auto-thresholding.
#' @param fg.thr an internal argument to pass calculated threshold to reduce redundant computation. Must be a numeric value.
#' @return a pixset with the selected pixels
#' @export
.fg_threshold <- function(img, fg.thresh = "kmeans", fg.adjust = 1, approx.res = 10000,
                         km = c(1L, 2L), fg.thr = NULL){
  if(is.null(fg.thr)){
    fg.thr <- threshold2(img,thr = as.character(fg.thresh),adjust = fg.adjust,
                         approx.res = approx.res, km = km,
                         return.thr.only = TRUE, thr.exact = FALSE)
    if(fg.thr >= 1){
      for(i in seq_len(5)){
        fg.thr <- fg.thr * 0.9
        if(fg.thr < 1){
          break
        }
      }
    }
    message(paste0("Foregound threshold selected: ",signif(fg.thr*100,4),"%"))

    if((fg.thresh == "kmeans" | fg.thresh == "otsu") && fg.thr < 0.4){
      message("Foreground threshold might be too low. Automatically increasing fg.adjust by 30%.")
      fg.thr <- fg.thr * 1.3
      message(paste0("New foregound threshold selected: ",signif(fg.thr*100,4),"%"))
    }
  }

  fg <- threshold2(img, thr = fg.thr, return.thr.only = FALSE, thr.exact = TRUE)

  return(fg)
}



#' @title Select Pixels of Uneaten Leaf From Scanned Image
#' @description get a binary-ized image of a leaf scan, removing background artifacts and eaten sections of the leaf.
#' @param object a cimg, pixset, or matrix, or array.
#' @param fg.thresh a threshold for selecting the foreground in the watershed transform. Can be either numeric, a string, or "kmeans", or "otsu". When set to "otsu" or "kmeans", the threshold is automatically selected by the internal function \code{threshold2()}. Default is "kmeans".
#' @param bg.thresh a threshold for selecting the background in the watershed transform. Can be either numeric, a string, "kmeans", or "otsu". When set to "kmeans" or "otsu", the threshold is automatically selected by the internal function \code{threshold2()}. Default is "10%".
#' @param fg.adjust used to adjust the automatic threshold. If the auto-threshold is at k, the effective threshold will be at \code{fg.adjust} * k.
#' @param blur.size a positive numeric value indicating the size of the median filter used to remove small speckles. Default is 2.
#' @param plot if \code{TRUE}, a plot of the original image and binary-ized image side-by-side will be plotted. Maybe slow.
#' @param save.plot.path the file path as a character string for saving the quality check plot. If set to \code{NA} (default), no plot will be saved.
#' @param save.plot.size an integer vector of length two defining the size of the quality check plot in the number of pixels. If set to "original", the size of the original image will be retained (same height and double the width).
#' @param return.cimg if \code{TRUE} (default), the function returns a 'cimg' object. Otherwise, the function returns a 'pixset'.
#' @param approx.res the number of pixels used in threshold approximation. Default is 10000.
#' @param km an integer vector of length two. The first value selects the the boundary rank in increasing means identified by kmeans clustering (defaults to 1, selecting the boundary that separates the two clusters with the lowest mean). The second value selects the k number of clusters to form (defaults to 2). Ignored when not auto-thresholding.
#' @param ws.thresh a threshold for selecting leaf pixels from a watershed transformed image. Can be either numeric, a string, "kmeans", or "otsu". When set to "otsu" or "kmeans", the threshold is automatically selected by the internal function \code{threshold2()}. Default is "kmeans".
#' @param px.size value passed to \code{px_size_calc()}. When set to \code{NA} (default), the 'px.size' attribute is extracted from the supplied \code{object}.
#' @details
#' Some quick notes:
#'
#' \code{fg.thresh} is better left at "kmeans", unless you know what parameter is best tuned for the set of images you will process.
#'
#' \code{fg.adjust} can be increased to pick up more of the foreground, and decreased if too much non-leaf pixels are misidentified.
#'
#' \code{bg.thresh} can be lowered occasionally when lighter spots of the leaf is mistaken as background.
#'
#' \code{blur.size} can be increased when small white speckles is present in the processed image.
#'
#' \code{km} can be toggled to change the number of clusters and the boundary rank selected when "kmeans" misbehaves.
#'
#' @return A 'cimg' object if \code{return.cimg} is set to \code{TRUE}, otherwise, a 'pixset'.
#' @note The code for the watershed method is adapted from Simon Barthelme's vignette https://cran.r-project.org/web/packages/imager/vignettes/pixsets.html. accessed date 2022-07-25.
#' @examples
#' file_path <- system.file("extdata/raw_scan.jpg",package="herbivar")
#' img <- load.image(file_path) %>%
#'    crop(empty.rm = "auto", cut_edge = 10) %>%
#'    add_px_size("dpi:300") %>%
#'    thin(3)
#'
#' plot(img)
#' img.cleaned <- clean_leaf(img)
#'
#' plot(img.cleaned)
#' @export
clean_leaf <- function(object, fg.thresh = "kmeans", bg.thresh = "10%",
                       fg.adjust = 1, blur.size = 2, plot = TRUE,
                       save.plot.path = NA, save.plot.size = "original",
                       return.cimg = TRUE, approx.res = 10000, km = c(1L, 2L),
                       ws.thresh = "kmeans", px.size = NA){
  if(is.na(px.size)){
    px.size <- attr(object,"px.size")
  }

  if(!(is.cimg(object) || is.pixset(object) || is.array(object) || is.matrix(object))){
    stop("Unsupported object type.'object' must be a cimg, pixset, array, or matrix.")
  } else {
    object <- as.cimg(object)
  }

  bg <- (!threshold2(object,thr = bg.thresh, approx.res = approx.res, km = km))
  fg <- .fg_threshold(object,fg.thresh = fg.thresh,fg.adjust = fg.adjust,
                     approx.res = approx.res, km = km)
  fg.thr <- attr(fg, "threshold")

  seed <- bg+2*fg
  p <- 1/(1+enorm(imgradient(object,"xy")))
  spec <- imager::spectrum(object)

  ws <- watershed2(seed = seed, p = p, spectrum = spec, thr = ws.thresh,
                   approx.res = approx.res, km = km)

  for(i in seq_len(9)){
    if( sum(ws) / (nPix(ws) * max_scale(ws)) > 0.3 ){
      break
    } else {
      if(i < 6){
        #Try different seeds
        ws <- watershed2(seed = seed, p = p, spectrum = spec, thr = ws.thresh,
                         approx.res = approx.res, km = km)
      } else {
        fg.thr <- fg.thr * (1 + 0.1)

        if(fg.thr >= 1) {
          break
        }

        fg <- .fg_threshold(object, fg.thr = fg.thr)
        seed <- bg+2*fg
        p <- 1/(1+enorm(imgradient(object,"xy")))
        ws <- watershed2(seed = seed, p = p, spectrum = spec, thr = ws.thresh,
                         approx.res = approx.res, km = km)
      }
    }
  }
  ws <- medianblur(ws,blur.size)

  if(!is.na(save.plot.path)){
    par.default <- graphics::par("mfrow","mar")
    if(save.plot.size == "original"){
      save.plot.size <- c(nrow(object)*2, ncol(object))
    }
    grDevices::png(save.plot.path,width = save.plot.size[1],
        height = save.plot.size[2])
    graphics::par(mfrow=c(1,2),mar=c(4,2,0.5,0.5))
    plot(object)
    plot(ws)
    grDevices::dev.off()
    graphics::par(par.default)
  }
  if(plot){
    par.default <- graphics::par("mfrow","mar")
    graphics::par(mfrow=c(1,2),mar=c(4,2,0.5,0.5))
    plot(object)
    plot(ws)
    graphics::par(par.default)
  }
  if(return.cimg){
    ws <- as.cimg(ws)
  }
  attr(ws,"px.size") <- px_size_calc(ws, px.size)
  invisible(ws)
}



#' @title Crop Out Non-Leaf Pixels
#' @description Crop out non-leaf pixels marked by the color blue as \code{NA}s. Non-leaf pixels need to be cropped out for further analyses.
#' @param object a cimg, pixset, or matrix, or array to be cropped.
#' @param thr a threshold, either numeric, "kmeans", or "otsu", or string for quantiles. If \code{FALSE} (default is "99"), no thesholding will be performed prior to cropping. Useful for when the colors are slightly impure.
#' @param invalid the value to replace non-leaf pixels as. Default is \code{NA}.
#' @param rgb.index an integer value \code{1L}, \code{2L}, or \code{3L}, indicating red, green, or blue colors respectively to be identified as non-leaf pixels.
#' @param px.size value passed to \code{px_size_calc()}. When set to \code{NA} (default), the 'px.size' attribute is extracted from the supplied \code{object}.
#'
#' @return a cropped 'cimg' object with only one color spectrum
#' @examples
#' file_path <- system.file("extdata/mock_leaf8.png",package="herbivar")
#' img <- load.image(file_path) %>% add_px_size("dpi:300")
#' plot(img)
#' cropped_img <- crop_leaf(img)
#' plot(cropped_img)
#'
#' analyze_holes(cropped_img) %>% print()
#'
#' @export
crop_leaf <- function(object, thr = "99", invalid = NA, rgb.index = 3L, px.size = NA){
  if(is.na(px.size)){
    px.size <- attr(object,"px.size")
  }

  if(!(is.cimg(object) || is.pixset(object) || is.array(object) || is.matrix(object))){
    stop("Unsupported object type.'object' must be a cimg, pixset, array, or matrix.")
  } else {
    object <- as.cimg(object)
  }

  if(!isFALSE(thr)){
    object <- as.cimg(threshold2(object, thr = thr))
  }

  if(imager::spectrum(object) == 1){ #Handle grayscale images
    rgb.index <- 1
    other.col.check <- TRUE
  } else {
    other.colors <- seq_len(3)[-rgb.index]
    other.col.check <- object[,,,other.colors[1]] < 0.3  & object[,,,other.colors[2]] < 0.3
  }
  object[object[,,,rgb.index] > 0.6 & other.col.check] <- invalid
  object[object[,,,rgb.index] < 0.95] <- 0
  object[object[,,,rgb.index] >= 0.95] <- 1
  if(imager::spectrum(object) > 1){
      out<-grayscale(object)
  } else {
      out <- object
    }
  attr(out,"px.size") <- px_size_calc(out, px.size)

  if((is.na(invalid) && !any(is.na(out))) || isTRUE(!any(out == invalid))){
    warning("No ", invalid, " detected in cropped image. Try to toggle the 'thr' argument or check if 'rgb.index' is set to the correct channel. ")
  }
  return(out)
}


#' @title Calculate Leaf Herbivory
#' @description calculate leaf herbivory in proportion, pixels, and mm2. Non-leaf parts, remaining leaf parts, and eaten leaf parts of the image matrix must be indicated by \code{NA}s, 0, and 1 (or 3) respectively.
#' @param object an object of type 'split_herb', 'matrix', 'array ', 'cimg', or 'pixset'.
#' @param type a vector of character string indicating what values to return. Partial string matching supported. "proportion" and "percent" returns relative proportion herbivory. "pixels" and "px" returns the number of pixels eaten. "mm2" and "real" returns the leaf area eaten in mm2.
#' @param px.size value passed to \code{px_size_calc()}. When set to \code{NA} (default), the 'px.size' attribute is extracted from the supplied \code{object}.
#' @return a vector of proportion, number of pixels, and milometer squared area of herbivory. The object must have a "px.size" attribute or the \code{px.size} argument must be defined to return values for mm2 leaf area removed.
#' @export
leaf_herb <- function(object, type = c("proportion","percent",
                                    "pixels","px","mm2","real"),
                      px.size = NA){
  if(inherits(object, "split_herb")){
    mat <- object$px
  } else {
    mat <- object
  }

  if(!(is.cimg(mat) || is.pixset(mat) || is.matrix(mat) || is.array(mat))){
    stop("Unsupported object type")
  }

  if(is.na(px.size)){
    px.size <- attr(mat,"px.size")
  }
  if("all"%in%type){
    type <- c("prop","px","real")
  }
  type <- match.arg(type, several.ok = TRUE)

  if(is.array(mat) && any(dim(mat)[c(-1,-2)] > 1)){
    stop("Unexpected dimension present. Matrix should be n X m")
  }

  na.v <- is.na(c(mat))
  if(!any(na.v)){
    warning("No NA detected; make sure the boundaries are cropped")
  }

  crp.mat <- c(mat)[!na.v]
  max.scale <- max_scale(mat)

  if(any(c("proportion","percent") %in% type)){
    prop.herb <- mean(crp.mat) / max.scale
  } else {
    prop.herb <- NA
  }
  if(any(c("px","pixels") %in% type)){
    px.herb <- sum(crp.mat) / max.scale
  } else {
    px.herb <- NA
  }
  if(any(c("mm2","real") %in% type)){
    px.size_mm <- px_size_calc(mat, px.size)
    real.herb <- sum(crp.mat) / max.scale * (px.size_mm$size)^2
  } else{
    real.herb <- NA
  }
  out <- c("prop"=prop.herb,"px"=px.herb,"mm2"=real.herb)
  return(out[!is.na(out)])
}


#' @title Calculate Leaf Area
#' @description calculate leaf area pixels and mm2. Non-leaf parts of the image matrix must be indicated by \code{NA}s.
#' @param object an object of type 'split_herb', 'matrix', 'array ', 'cimg', or 'pixset'.
#' @param px.size value passed to \code{px_size_calc()}. When set to \code{NA} (default), the 'px.size' attribute is extracted from the supplied \code{object}.
#' @return a vector of the number of pixels and milometer squared area of leaf area. The object must have a "px.size" attribute or the \code{px.size} argument must be defined to return values for mm2 leaf area.
#' @export
leaf_area <- function(object, px.size = NA){
  if(inherits(object, "split_herb")){
    mat <- object$px
  } else {
    mat <- object
  }

  if(is.na(px.size)){
    px.size <- attr(mat,"px.size")
  }

  if(is.array(mat) && any(dim(mat)[c(-1,-2)] > 1)){
    stop("Unexpected dimension present. Matrix should be n X m")
  }

  if(!(is.cimg(mat) || is.pixset(mat) || is.matrix(mat) || is.array(mat))){
    stop("Unsupported object type")
  }

  na.v <- is.na(c(mat))
  if(!any(na.v)){
    warning("No NA detected; make sure the boundaries are cropped")
  }

  px.tot <- sum(!na.v)

  px.size_mm <- px_size_calc(mat, px.size)
  real.tot <- px.tot * (px.size_mm$size)^2
  return(c("px"=px.tot,"mm2"=real.tot))
}


#' @title Threshold Image With Missing Values And Error Handling
#' @description Basically the same thing as \code{imager::threshold()}, but handles missing values in the cimg object, preserves "px.size" attribute, increases the approximation resolution, handles error generated by k-means approximation, and adds "otsu" threshold method from \code{EBImage::otsu()}. If the image has more than one color channels, the threshold is calculated from the grayscale image, but the number of color channels is preserved in the returned image.
#' @details see \code{?imager::threshold()}
#' @param im the image
#' @param thr a threshold, either numeric, "kmeans", or "otsu", or string for quantiles. If \code{thr.exact} is \code{TRUE}, the value must be numeric.
#' @param approx skip pixels when computing quantiles in large images (defaults to \code{TRUE})
#' @param adjust use to adjust the automatic threshold: if the auto-threshold is at k, effective threshold will be at adjust*k (default 1)
#' @param approx.res the number of pixels used in threshold approximation. Default is 10000.
#' @param km an integer vector of length two. The first value selects the the boundary rank in increasing means identified by kmeans clustering (defaults to 1, selecting the boundary that separates the two clusters with the lowest mean). The second value selects the k number of clusters to form (defaults to 2). Ignored when not auto-thresholding.
#' @param return.thr.only if \code{TRUE} (default to \code{FALSE}), return the calculated numeric threshold only, otherwise a selected pixset of the image will be returned.
#' @param thr.exact if \code{TRUE}, the exact threshold supplied by \code{thr} is used. Used internally to reduce redundant computation.
#' @return a pixet with select pixels if \code{return.thr.only = FLASE}, otherwise, a numeric value is returned.
#' @note The code for much of the function is obtained from Simon Barthelme's \code{imager::threshold()}. version 0.42.13.
#' @export
threshold2<-function (im, thr = "kmeans", approx = TRUE, adjust = 1,
                      approx.res = 10000, km = c(1L, 2L),
                      return.thr.only = FALSE, thr.exact = FALSE){
  if(!thr.exact){
    # Calculate 'thr' if not using exact supplied value
    if (is.character(thr)) {
      if(imager::spectrum(im) > 1){
        imgs <- imager::grayscale(im)
      } else {
        imgs <- im
      }
      if (nPix(imgs) > approx.res && approx) {
        v <- imgs[round(seq(1, imager::nPix(imgs), l = approx.res))]
      }
      else {
        v <- imgs
      }
      if (tolower(thr) == "kmeans") {
        thr <- tryCatch(
          cut_kmeans(c(v), km = km) * adjust,
          error = function(e){
            cut_kmeans(c(imgs), km = km) * adjust
          })
      } else if(tolower(thr) == "otsu"){
        thr <- EBImage::otsu(
          array2Image(imgs),
          range = c(0,max_scale(imgs)) * adjust
        )
      } else {
        if(adjust != 1){
          warning("'adjust' ignored when 'thr' not set to 'kmeans' or 'otsu'")
        }
        regexp.num <- "\\d+(\\.\\d*)?|\\.\\d+"
        .is_inst("stringr", stop.if.false = TRUE)
        qt <- stringr::str_match(thr, regexp.num)[, 1] %>%
          as.numeric()
        thr <- quantile(v, qt/100,na.rm = TRUE)
      }
    }
  }
  if(return.thr.only){
    return(thr)
  } else {
    a <- im > thr
    attr(a, "threshold") <- thr
    attr(a,"px.size") <- attr(im,"px.size")
    return(a)
  }
}



#' @title Parse Holes And Extract Within Leaf Herbivory Data
#' @description Split pixels into different herbivory regions ("holes") and measure hole and leaf level data. A pre-processing step for use with subsequent functions such as \code{split2ppp()}, \code{nn_dist()}, \code{pair_dist()}, \code{leaf_area()}, and \code{leaf_herb()}
#' @param object A cimg, pixset, matrix, or array that has been cropped via \code{crop_leaf()}
#' @param min_prop a numeric value between 0 and 1 indicating the minimum proportion herbivory threshold for inclusion. This gets rid of artifacts in the image that are too small to actually be real herbivory or biologically non-trivial herbivory. Default is 0.0001.
#' @param plot if \code{TRUE} (default is \code{FALSE}), each hole splitted from the image will be plotted side-by-side. If more than 20 holes are detected, the user will be prompted to decide whether to proceed with plotting. Can be slow if the number of holes and image resolution is high.
#' @param tolerance a numeric value between 0 and 1 determining if two pixels belong to the same region. Defaults to 0.1.
#' @param silent if \code{TRUE} (default is \code{FALSE}), suppress messages.
#' @param image_id a character string supplied to name the returned object for book keeping.
#' @return
#' an object of class 'split_herb' and 'list'.
#'
#' \code{n_holes}: The number of holes. Holes with proportion area less than \code{min_prop} are excluded.
#'
#' \code{hole_prop}: The proportion area of each hole. Returns NA if \code{n_hole} is 0.
#'
#' \code{leaf_area}: The leaf area in pixels and mm2.
#'
#' \code{is.margin}: A vector of logical values indicating whether each parsed hole is marginal or internal. Returns NA if \code{n_hole} is 0.
#'
#' \code{hole_perimeter}: A \code{n_hole} X 2 matrix of values of the perimeter of each parsed hole returned by the function \code{hole_perimeter()}. The \code{non_leaf_border} argument is set to \code{TRUE}. Returns NA if \code{n_hole} is 0.
#'
#' \code{hole_centroid}: A \code{n_hole} X 2 matrix of the the centroid coordinates of each parsed hole. Returns NA if \code{n_hole} is 0.
#'
#' \code{px}: A binary-ized pixset of the supplied \code{object} whose value is above 0.8.
#'
#' \code{min_prop}: The supplied \code{min_prop} argument
#'
#' \code{px.size}: The length in millimeter of a pixel. If unsuccessfully extracted from the \code{object} \code{px.size} attribute, only results in pixels will be returned for other function outputs.
#'
#' \code{imlist}: A list of images of class \code{imlist} of each parsed hole.
#'
#' \code{image_id}: The supplied \code{image_id} argument
#'
#' @export
analyze_holes <- function(object, min_prop = 10^-4, plot = FALSE,
                          tolerance = 0.1, silent = FALSE, image_id = NA){
  if(!any(is.na(c(object)))){
      warning("No NA detected; make sure the boundaries are cropped")
  }
  px.size <- attr(object,"px.size")

  if(is.array(object) || is.matrix(object)){
    object <- as.cimg(object)
  }

  if(is.cimg(object)){
    px <- object > 0.8
  } else {
    if(is.pixset(object)){
      px <- object
    } else {
      stop("Unsupported object type.")
    }
  }

  if(imager::spectrum(px) > 1){
    warning("Image not in grayscale. Converting to grayscale.")
    px <- grayscale(px)
  }
  attr(px,"px.size") <- px.size

  lab <- label(px, tolerance = tolerance) * as.cimg(px)
  split.set <- unique(lab) %>% {
    .[. > 0 & !is.na(.)]
  }
  imlist <- split.set %>% map_il(function(v) lab == v) %>%
    lapply(function(x){
      attr(x,"px.size") <- px.size
      return(as.cimg(x))
    }) %>% as.imlist(check=FALSE)

  hole_prop <- simplify2array(lapply(imlist,
                                     function(x) {
                                       leaf_herb(x,type="proportion")
                                     }))
  imlist <- imlist[hole_prop > min_prop]
  n_holes <- length(imlist)

  if(plot && n_holes > 20){
    plot <- ifelse(
      utils::menu(c("Yes","No"),
           title = paste0(n_holes,
                          " holes detected; plot will be slow! Proceed with plot?")) == 1,
      TRUE,
      FALSE)
  }
  if(plot && n_holes > 0){
    imlist %>% map_il(function(x){
      x %>% colorise(.,
                     px = ~. > 0.99,
                     col = "violet")
    }) %>%
      spatstat.geom::plot.imlist(plotcommand="plot")
  }

  if(n_holes > 0){
    hole_prop <- hole_prop[hole_prop > min_prop]

    is_margin <- simplify2array(lapply(
      imlist,
      FUN = function(x){
        is.margin(x)
      }
    ))

    hole_peri <- do.call("rbind",
                         lapply(imlist,FUN = function(x) {
                           hole_perimeter(x,non_leaf_border = TRUE)
                         }))

    hole_cen <- do.call("rbind",
                        lapply(
                          imlist,
                          FUN = function(x) {
                            (colMeans(which(x[, , 1, 1] > 0.99, arr.ind = TRUE)))
                          }
                        ))

  } else {
    hole_prop <- NA
    is_margin <- NA
    hole_peri <- NA
    hole_cen <- NA
  }

  out<-list(
    "n_holes" = n_holes,
    "hole_prop" =  hole_prop,
    "leaf_area" = leaf_area(px),
    "is.margin" = is_margin,
    "hole_perimeter" = hole_peri,
    "hole_centroid" = hole_cen,
    "px" = px,
    "min_prop" = min_prop,
    "px.size" = px.size,
    "imlist" = imlist,
    "image_id" = image_id
  )
  if(!silent){
    cat(paste0("Number of holes detected: ",out$n_holes,"\n"))
  }

  out <- structure(out,
                   class = c("split_herb", "list"))

  invisible(out)
}





#' @title Display A List of Images Using Base Graphics
#' @description Plot different regions of herbivory form an object of class 'split_herb'
#' @param x a 'split_herb' object
#' @param prompt if \code{TRUE} (default), display a prompt for user to select whether to proceed with plotting when the number of holes is above 20.
#' @param ... extra arguments passed to \code{spatstat.geom::plot.imlist()}
#' @return NULL
plot.split_herb <- function(x, prompt = TRUE, ...){
  if(!inherits(x, "split_herb")){
    stop("Object must of of class 'split_herb'.")
  }

  if(x$n_holes > 20 && prompt){
    plot <- ifelse(
      utils::menu(c("Yes","No"),
           title = paste0(x$n_holes,
                          " holes detected; plot will be slow! Proceed with plot?")) == 1,
      TRUE,
      FALSE)
  }
  if(x$n_holes > 0){
    x$imlist %>% map_il(function(img){
      img %>% colorise(.,
                     px = ~. > 0.99,
                     col = "violet")
    }) %>%
      spatstat.geom::plot.imlist(plotcommand="plot", ...)
  }
}

#' @title Compute nearest neighbor distance and perform Clark-Evans test
#' @description
#' Compute nearest neighbor distance and perform Clark-Evans (1954) test
#' @param object a matrix with two columns (x and y coordinates) or a 'split_herb' object
#' @param alternative the alternative hypothesis
#' @param silent If \code{TRUE}, the result of the test is not printed
#' @return If \code{silent = TRUE}, the nearest neighbor distances are returned along with the result of the Clark-Evans test. If \code{silent = TRUE}, only the nearest neighbor distances are returned.
#' @references
#' Clark, P. J., and F. C. Evans. 1954. Distance to Nearest Neighbor as a Measure of Spatial Relationships in Populations. Ecology 35:445–453.
nn_dist <- function(object, # expect a matrix with two columns or split_herb
                    alternative = c("two.sided","clustered", "regular",
                                    "greater","lesser"),
                    silent = FALSE){
  if(inherits(object, "split_herb")){
    r<-Rfast::rowMins(Rfast::upper_tri(Rfast::Dist(object$hole_centroid),
                                       suma = FALSE, diag = FALSE), value = TRUE)
    rho <- object$n_holes / object$leaf_area["px"]
    names(rho) <- NULL
    r_E_bar <- 0.5 / sqrt(rho)
    r_A_bar<- mean(r)
    R <- r_A_bar / r_E_bar
    SE_r_E_bar <- 0.26136 / sqrt(object$n_holes * rho)
    c <- (r_A_bar - r_E_bar) / SE_r_E_bar

    alternative <- match.arg(alternative)
    if(alternative == "two.sided"){
      p <- pnorm(abs(c),lower.tail = F)*2
    } else if(alternative == "clustered" || alternative == "lesser"){
      p <- pnorm(c,lower.tail = T)
    } else if(alternative == "regular" || alternative == "greater"){
      p <- pnorm(c,lower.tail = F)
    } else {
      stop("Acceptable 'alternative' values are: ",
           paste0(c("two.sided","clustered", "regular","greater","lesser"),
                  collapse = ", "))
    }

    test_stat<-c("rho" = rho, "rA" = r_A_bar, "rE" = r_E_bar,
                 "SErE" = SE_r_E_bar, "R" = R, "c" = c, "P" = p)
    if(!silent){
      cat("Clark-Evans Nearest Neighbor Z-Test","\n","\n")
      print(signif(test_stat[seq_len(4)],4))
      cat("\n")
      print(signif(test_stat[5:7],4))
      message(ifelse(p < 0.05,
                     ifelse( R > 1,
                             "Significant regularity",
                             "Significant aggregation"
                     ),
                     "No deviation from randomness detected"
      ))
      message("No correction supported at present")
    }
    invisible(
      list("test_stat" = test_stat,
           "r" = r)
    )
  } else {
    if(!(is.matrix(object) || is.array(object) || is.data.frame(object))){
      stop("Object type not supported")
    } else {
      if((dim(object)[2] != 2))
        stop("Object needs to be a n x 2 matrix")
    }
    r<-dist(object) %>%
      as.matrix() %>% apply(.,1,function(x){
        min(x[x>0])
      })
    return(r)
  }
}

#' @title Find All Pairwise Distance
#' @description Get all pairwise distance between centroids
#' @return an n choose 2 by 3 matrix of pairwise distance, where n is the number of centroids.
#' @param object An object of class 'split_herb', or a n by 2 matrix of centroid position as a matrix, array or data.frame.
#' @export
pair_dist<-function(object){
  if(inherits(object,"split_herb")){
    object <- object$hole_centroid
  } else {
    if(!(is.matrix(object) || is.array(object) || is.data.frame(object))){
      stop("Object type not supported")
    } else {
      if((dim(object)[2] != 2))
        stop("Object needs to be a n x 2 matrix")
    }
  }
  cen.dist <- Rfast::upper_tri(Rfast::Dist(object), suma = FALSE, diag = FALSE)
  out <- data.frame(t(Rfast::comb_n(nrow(object), 2)),
                    cen.dist)
  names(out) <- c("cent1","cent2","dist")
  return(out)
}



#' @title Check Margin
#' @description Check if the selected pixels (must have value 1) is on the leaf margin (i.e. bordering \code{NA}s).
#' @param mat a cimg, pixset, matrix, or array
#' @return an atomic logical value
#' @export
is.margin <- function(mat){
  if(!is.matrix(mat)){
    if(is.cimg(mat) || is.array(mat) || is.pixset(mat)){
      if(imager::spectrum(mat) != 1){
        mat <- grayscale(mat)
      }
      mat <- mat[,,1,1]
    } else {
      stop("Unsupported object type")
    }
  }

  max.scale <- max_scale(mat)

  if(max.scale > 1){
    warning("Maximum pixel value is not 1. Try thresholding the image.")
  }

  if(!any(is.na(c(mat)))){
    warning("No NA detected; make sure the boundaries are cropped")
  }

  mat1 <- mat[-1,]
  mat2 <- mat[-nrow(mat),]
  mat3 <- mat[,-1]
  mat4 <- mat[,-ncol(mat)]

  out <- any(as.vector(is.na(mat1) & (mat2 > 0.99)),na.rm = T) ||
    any(as.vector(is.na(mat2) & (mat1 > 0.99)),na.rm = T) ||
    any(as.vector(is.na(mat3) & (mat4 > 0.99)),na.rm = T) ||
    any(as.vector(is.na(mat4) & (mat3 > 0.99)),na.rm = T)
  return(out)
}


#' @title Calculate Perimeter
#' @description Find the perimeter of selected pixels (must have value 1) including or excluding non-leaf borders.
#' @param mat a cimg, pixset, matrix, or array
#' @param non_leaf_border if \code{TRUE} (default is \code{FALSE}), return perimeter that includes non-leaf borders (edges that separate eaten leaf area and non-leaf area).
#' @param px.size value passed to \code{px_size_calc()}. When set to \code{NA} (default), the 'px.size' attribute is extracted from the supplied \code{mat} object.
#' @return a vector of the perimeter in the number of pixels and millimeters. The object must have a "px.size" attribute or the \code{px.size} argument must be defined to return values for mm perimeter
#' @export
hole_perimeter <- function(mat, non_leaf_border = FALSE, px.size = NA){
  if(is.na(px.size)){
    px.size <- attr(mat,"px.size")
  }
  px.size_mm <- px_size_calc(mat, px.size)

  if(!is.matrix(mat)){
    if(is.cimg(mat) || is.array(mat) || is.pixset(mat)){
      if(imager::spectrum(mat) != 1){
        mat <- grayscale(mat)
      }
      mat <- (mat[,,1,1])
    } else {
      stop("Unsupported object type")
    }
  }
  max.scale <- max_scale(mat)
  mat_cimg <- as.cimg(mat)

  if(max.scale > 1){
    warning("Maximum pixel value is not 1. Try thresholding the image.")
  }

  if(!any(is.na(c(mat)))){
    warning("No NA detected; make sure the boundaries are cropped")
  }

  perim_total <- imager::imeval(mat_cimg,~.> 0.99 & !is.na(.)) %>%
    imager::boundary() %>%
    as.vector() %>%
    sum()

  if(!non_leaf_border){
    mat1 <- mat[-1,]
    mat2 <- mat[-nrow(mat),]
    mat3 <- mat[,-1]
    mat4 <- mat[,-ncol(mat)]

    border_NA_perim <- sum((((is.na(mat1) & (mat2 > 0.99)) | (is.na(mat2) & (mat1 > 0.99)))[,-1]) | (((is.na(mat3) & (mat4 > 0.99)) | (is.na(mat4) & (mat3 > 0.99)))[-1,]),na.rm = TRUE)

    perim_out <- perim_total - border_NA_perim
  } else {
    perim_out <- perim_total
  }
  return(c("px" = perim_out, "mm2" = perim_out * px.size_mm$size))
}


#' @title Find Major Axis Length of Leaf
#' @description Takes a cropped image and find the maximum euclidean distance between leaf borders. Some caveats apply. For instance, if the leaf is not straight, or if there are speckles in the background, then the distance would be off.
#' @param object an object of type 'split_herb', 'matrix', 'array ', 'cimg', or 'pixset'.
#' @param filer_speckles If \code{TRUE} (default), the largest connected patch is treated as the leaf and all other segmented patches are ignored.
#' @param px.size	value passed to px_size_calc(). When set to NA (default), the 'px.size' attribute is extracted from the supplied object
#' @return a vector of the number of pixels and milometer maximum distance between leaf border pixels. he object must have a "px.size" attribute or the px.size argument must be defined to return values for mm2 distance.
#'
leaf_length <- function(object, filer_speckles = TRUE, px.size = NA){
  if (is.na(px.size)) {
    px.size <- attr(object, "px.size")
  }
  if (inherits(object, "split_herb")) {
    object <- object$px
  }
  object <-as.cimg(object)

  object <- rbind(
    rep(NA,ncol(object)+2),
    cbind(rep(NA,nrow(object)),object[,,1,1],rep(NA,nrow(object))),
    rep(NA,ncol(object)+2)
  ) %>% as.cimg()

  if(filer_speckles){
    iml <- imager::split_connected(
      imager::imeval(object, ~ !is.na(.)),
      high_connectivity = TRUE)

    px.len <- iml[[
      lapply(iml,
             function(x){
               sum(x)
             }) %>%
        simplify2array() %>%
        which.max()
    ]] %>%
      imager::boundary() %>%
      .[,,1,1] %>%
      which(arr.ind = TRUE) %>%
      dist() %>%
      c() %>%
      max()
  } else {
    px.len <- imager::imeval(object, ~ !is.na(.)) %>%
      imager::boundary() %>%
      .[,,1,1] %>%
      which(arr.ind = TRUE) %>%
      dist() %>%
      c() %>%
      max()
  }

  if(is.null(px.size)){
    real.len <- NULL
  } else {
    real.len <- px.len * px.size$size
  }
  return(c(px = px.len, mm2 = real.len))
}


#' @title Print Value
#' @description print values from a 'split_herb' object
#' @param x a 'split_herb' object
#' @param ... additional arguments
#' @param digits number of digits to display. Default is four.
#' @return a vector of numeric values
#' @export
print.split_herb <- function(x, ..., digits = 4){
    cat("Image ID = ", x$image_id ,"\n", sep = "")
    cat("Minimum hole detection threshold: ", x$min_prop, "\n", sep = "")
    cat("\n")
    print(signif(c("total_holes" = x$n_holes, "toal_margin" = sum(x$is.margin), "prop_margin" = sum(x$is.margin)/x$n_holes),digits))
    cat("\n")
    if(!is.null(x$px.size)){
      print(
        signif(
          c("prop_herb" = sum(x$hole_prop),
            "leaf_area_mm2"= unname(x$leaf_area["mm2"]),
            "tot_herb_perim_mm2" = tryCatch(sum(x$hole_perimeter[,"mm2"]),
                                           error = function(e){
                                             NA
                                           })
          ),
          digits))
    } else {
      print(
        signif(
          c("prop_herb" = sum(x$hole_prop),
            "leaf_area_px"= unname(x$leaf_area["px"]),
            "tot_herb_perim_px" = tryCatch(sum(x$hole_perimeter[,"px"]),
                                           error = function(e){
                                             NA
                                           })
            ),
          digits))
    }
}



#' @title Plot one dimensional image
#' @description plot one dimensional image with pixel value plotted as a line. Internal function of \code{plot.cimg()}.
#' @param x the image
#' @param ... additional arguments passed to \code{plot.default()}
#' @return NULL
#' @note The code for the function is obtained from Simon Barthelme's \code{imager:::plot.singleton()}. version 0.42.13.
#' @export
plot.singleton <- function (x, ...){
  varying <- if (width(x) == 1)
    "y"
  else "x"
  l <- max(dim(x)[1:2])
  if (imager::spectrum(x) == 1) {
    plot(1:l, as.vector(x), xlab = varying, ylab = "Pixel value",
         type = "l", ...)
  }
  else if (imager::spectrum(x) == 3) {
    ylim <- range(x)
    plot(1:l, 1:l, type = "n", xlab = varying, ylim = ylim,
         ylab = "Pixel value", ...)
    cols <- c("red", "green", "blue")
    for (i in 1:3) {
      graphics::lines(1:l, as.vector(channel(x, i)), type = "l",
                      col = cols[i])
    }
  }
  else {
    stop("Unsupported image format")
  }
}


#' @title Plot Image Using Base Graphics Using Missing Value Handling
#' @description plot image the same way as \code{imager::plot.cimg()}. The only difference is that the \code{rescale} is automatically set to \code{FALSE} when the image contains missing pixel values. see \code{?imager::plot.cimg()} for more details.
#' @param x the image
#' @param frame which frame to display, if the image has depth > 1
#' @param xlim x plot limits (default: 1 to width)
#' @param ylim y plot limits (default: 1 to height)
#' @param xlab x axis label
#' @param ylab y axis label
#' @param rescale rescale pixel values so that their range is \eqn{[0,1]}
#' @param colourscale,colorscale an optional colour scale (default is gray or rgb)
#' @param interpolate should the image be plotted with antialiasing (default \code{TRUE})
#' @param axes whether to draw axes (default \code{TRUE})
#' @param main main title
#' @param xaxs,yaxs The style of axis interval calculation to be used for the axes. See \code{?par()}
#' @param col.na which colour to use for \code{NA} values, as R rgb code. The default is "rgb(0,0,0,0)", which corresponds to a fully transparent colour.
#' @param asp aspect ratio.
#' @param ... additional arguments passed to \code{plot.default()}
#' @return NULL
#' @note The code for the function is obtained from Simon Barthelme's \code{imager:::plot.singleton()}. version 0.42.13.
#' @export
plot.cimg <- function(x, frame, xlim = c(1, width(x)),
                      ylim = c(height(x), 1), xlab = "x", ylab = "y",
                      rescale = TRUE, colourscale = NULL,
                      colorscale = NULL, interpolate = FALSE, axes = TRUE, main = "",
                      xaxs = "i", yaxs = "i", asp = 1, col.na = grDevices::rgb(0, 0, 0, 0),
                      ...) {
  v <- unique(c(x))
  if(length(v[!is.na(v)]) < 2){
    rescale <- FALSE
  }

  if (nPix(x) == 0)
    stop("Empty image")
  im <- x
  if (depth(im) > 1) {
    if (missing(frame)) {
      warning("Showing first frame")
      frame <- 1
    }
    im <- imager::frame(x, frame)
  }
  if (1 %in% dim(im)[1:2]) {
    plot.singleton(im, ...)
  }
  else {
    if (is.character(asp) && asp == "varying") {
      plot(1, 1, xlim = xlim, ylim = ylim, xlab = xlab,
           ylab = ylab, type = "n", xaxs = xaxs, yaxs = yaxs,
           axes = axes, ...)
      grDevices::as.raster(im, rescale = rescale, colorscale = colorscale,
                colourscale = colourscale, col.na = col.na) %>%
        graphics::rasterImage(1, height(im), width(im), 1, interpolate = interpolate)
      graphics::title(main)
    }
    else if (is.numeric(asp)) {
      graphics::plot.new()
      graphics::plot.window(xlim = xlim, ylim = ylim, asp = asp,
                  xaxs = xaxs, yaxs = yaxs, ...)
      rst <- grDevices::as.raster(im, rescale = rescale, colorscale = colorscale,
                       colourscale = colourscale, col.na = col.na)
      graphics::rasterImage(rst, 1, nrow(rst), ncol(rst), 1, interpolate = interpolate)
      graphics::title(main)
      if (axes) {
        graphics::axis(1)
        graphics::axis(2)
      }
    }
    else {
      stop("Invalid value for parameter asp")
    }
  }
  invisible(x)
}

#' @title Plot image list
#' @description plot image list via \code{spatstat.geom::plot.imlist()}
#' @param x an object of class 'imlist'
#' @param main a character string for the plot title
#' @param interpolate a logical value indicating whether to interpolate the raster
#' @param ... additional arguments passed to \code{spatstat.geom::plot.imlist()}
#' @return \code{NULL}
plot.imlist <- function(x,main = "", interpolate = FALSE, ...){
  spatstat.geom::plot.imlist(x,plotcommand = "plot", main = main, interpolate = interpolate, ...)
}


# ss <- function(k, mat.dist, method = "silhouette", nboot = 10){
#   ss <- seq_len(nboot)
#
#   for (i in seq_len(nboot)){
#     km <- kmeans(mat.dist, k)
#     if(method == "silhouette"){
#       ss[i] <- mean(silhouette(km$cluster,mat.dist)[,3])
#     } else if(method == "elbo"){
#       ss[i] <- km$tot.withinss
#     }
#   }
#   return(mean(ss))
# }
#
# ss_plot <- function(mat, k, method = "silhouette", plot = TRUE, nboot = 10){
#   mat.dist <- dist(mat)
#   ss.v<- vapply(k, FUN = function(k,mat.dist, method, nboot){
#     ss(k,mat.dist, method = method, nboot = nboot)
#   }, FUN.VALUE = numeric(1),
#   mat.dist = mat.dist,
#   method = method,
#   nboot = nboot)
#   if(method == "elbo"){
#     ss.v <- cumsum(ss.v)/k
#   }
#   d <- data.frame("k" = k, "ss" = ss.v)
#   if(plot){
#     plot(d$ss~d$k)
#   }
#   invisible(d)
# }

