## ---- include=FALSE-----------------------------------------------------------
# vignette: >
#   %\VignetteIndexEntry{Using_herbivar_to_Fit_Neutral_Models}
#   %\VignetteEngine{knitr::rmarkdown}
#   %\VignetteEncoding{UTF-8}

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(fig.align = "center", comment = NA, eval = TRUE)

## ---- include = FALSE---------------------------------------------------------
# This document is being updated: 
# to do: 
# Motivation section in the intro explaining the use / application of the model 
# Biological interpretation of model 
# Make dalloT() more explicit
# Model output interpretation section. What to make of the parameter etc 
# Include worked example using real datasets. Explain how the package can be useful. -- Use image read from dames rocket photos
# Demo randomize leaves


## -----------------------------------------------------------------------------
#install.packages("BiocManager")
#BiocManager::install("EBImage")
#install.packages("devtools")
if(suppressMessages(!require(herbivar))){
  devtools::install_github("vsbpan/herbivar", build_vignettes = FALSE, dependencies = TRUE)
} else {
  message("Sweet! Herbivar is installed!")
}


## -----------------------------------------------------------------------------
# Generate some numbers
x <- ralloT(10000, lambda = 3)

# Check number of computer cores available
parallel::detectCores()

# Compute log likelihood with 4 computer cores
# Compute the same expression without parallelization
# microbenchmark::microbenchmark(
#   "no parallel" = sum(dalloT(x, lambda = 1, log = TRUE, by = 0.000001, parallel = FALSE)),
#   "with parallel" = sum(dalloT(x, lambda = 1, log = TRUE, by = 0.000001,
#                                parallel = TRUE, cores = 4)),
#   times = 1)
# Unit: seconds
#           expr      min       lq     mean   median       uq      max neval
#    no parallel 27.10942 27.10942 27.10942 27.10942 27.10942 27.10942     1
#  with parallel 24.49700 24.49700 24.49700 24.49700 24.49700 24.49700     1


## -----------------------------------------------------------------------------
# Compute density function using mean.phi.T paramterization or lambda parameterization
dalloT(0.5, mean.phi.T = 0.1, 
       min.phi = 0.01, max.phi = 1, a = 1.5)
dalloT(0.5, lambda = get_lambda(mean.phi.T = 0.1, 
                                min.phi = 0.01, max.phi = 1, a = 1.5), 
       min.phi = 0.01, max.phi = 1, a = 1.5)

## -----------------------------------------------------------------------------
# Get the 0.1 to lambda and back
get_mean_phi_T(
  get_lambda(mean.phi.T = 0.1, 
             min.phi = 0.01, max.phi = 1, a = 1.5), 
  min.phi = 0.01, max.phi = 1, a = 1.5)

## -----------------------------------------------------------------------------
# Generate some fake herbivory data
set.seed(12)
x <- ralloT(1000, mean.phi.T = 0.123)


allo_fit <- fit_allo_herb(x, method = "Brent") # By default, mean.phi.T is fitted
allo_fit

# Fit two variables at once
allo_fit2 <- fit_allo_herb(x,
              optim.vars = c("mean.phi.T","a"),
              init = c(10, 1),
              by = 0.001,
              method = "Nelder-Mead",
              cores = 1, # setting cores > 1, enables parallel
              id = "This lablel is passed to the object") 
allo_fit2

## -----------------------------------------------------------------------------
class(allo_fit)

## -----------------------------------------------------------------------------
names(allo_fit)
coef(allo_fit, se = TRUE)

## -----------------------------------------------------------------------------
# Generate some fake herbivory data
set.seed(12)
x <- ralloT(1000, mean.phi.T = 0.123)

htlnorm_fit <- fit_generic_null(x, family = "htlnorm", method = "BFGS", id = "hmmmmmm")
htlnorm_fit


zoibeta_fit <- fit_generic_null(x, family = "zoibeta", method = "Nelder-Mead")
zoibeta_fit



## -----------------------------------------------------------------------------
compare_dist(data_list = list("obs" = allo_fit$data, 
                              "pred" = predict(allo_fit)),
             test = c("ks", "kl","ad","chisq"), 
             bin_size = 0.01
            )

## -----------------------------------------------------------------------------
data <- ralloT(1000, lambda = 3)
probe_dist(data, probes = c("mean", "var", "Skew","median"))

## -----------------------------------------------------------------------------
#Simulate distributions
allo_probed <- lapply(seq_len(100), function(i){
  x <- ralloT(1000, lambda = 3, max.phi = 1)
  probe_dist(x)
}) %>%
  do.call("rbind",.)

allo_probed2 <- lapply(seq_len(100), function(i){
  x <- ralloT(1000, lambda = 3, max.phi = 0.5)
  probe_dist(x)
}) %>%
  do.call("rbind",.)

# Bind everything together and create a new column that keeps track of how each sample is generated
probed.data <- rbind(
  data.frame("distribution" = "max.phi = 1", allo_probed),
  data.frame("distribution" = "max.phi = 0.5", allo_probed2)
)

## -----------------------------------------------------------------------------
vegan::rda(probed.data[,-1]) %>%
  get_biplot(choices = c(1,2), 
             group = probed.data$distribution) + 
  ggplot2::theme_bw(base_size = 15) + 
  ggplot2::labs(color = "Distribution")

## -----------------------------------------------------------------------------
vegan::rda(probed.data[,-1] ~ probed.data$distribution)

## -----------------------------------------------------------------------------
# Likelihood ratio test
# The HTLN model is the candidate model and the neutral herbivory model is the reference model
LRT(model_candidate = htlnorm_fit,
    model_ref = allo_fit)

## -----------------------------------------------------------------------------
# Akaike's Information Criterion
AIC(allo_fit) # extract single criterion
AIC(htlnorm_fit, allo_fit, zoibeta_fit) # Or provide multiple models to get a table

# Akaike's small sample size Corrected Information Criterion
AICc(allo_fit)

# Bayesian information criterion
BIC(allo_fit)


## -----------------------------------------------------------------------------
predict_list(list("a" = allo_fit,
                  "b" = allo_fit,
                  "c" = allo_fit), 
             n.sim = 3, 
             return.obs = FALSE)

## -----------------------------------------------------------------------------
compare_dist_list(list("a" = allo_fit,
                       "b" = allo_fit,
                       "c" = allo_fit),
                  test = c("ks","ad","kl"), 
                  nboot = 2, 
                  silent = TRUE) 

## -----------------------------------------------------------------------------
probe_dist_list(
  list("a" = x,"b" = x, "c" = x), 
  probes = c("mean", "Hoover", "J.index", "cd", "cv", "N","lac","Gini")
)

## -----------------------------------------------------------------------------
plot_distributions(
  purrr::map(predict_list(list(allo_fit)), 1)
) %>% suppressMessages()

## -----------------------------------------------------------------------------
set.seed(12)
z <- rallo(100, max.phi = 0.4)
bite_size_fit <- fit_bite_size(z, 
                               min.phi = 0.005, 
                               family = "all")
bite_size_fit

## -----------------------------------------------------------------------------
# High lambda phenotype
lambda_h <- 1

# Low lambda phenotype
lambda_l <- 0.1

# n simulations
n <- 1000

# Simulate herbivory as one would observe them in the field
set.seed(100)
y <- c(ralloT(n, lambda = lambda_h), ralloT(n, lambda = lambda_l))

# Simulate phenotype data
x <- c(rep(lambda_h, n), rep(lambda_l, n)) 

# r2 benchmark
var(predict(lm(y~x))) / var(y)


## -----------------------------------------------------------------------------
# Histogram of included example data set
plot_distributions(herb_data_example, by = 0.05,type = "hist")


## -----------------------------------------------------------------------------
# Fit neutral model for each data set
lab_herb_fit <- fit_allo_herb(herb_data_example$lab, method = "Brent")
field_herb_fit <- fit_allo_herb(herb_data_example$field, method = "Brent")

# Select some interesting statistical probes
probes <- c("mean","var","max","Skew","Kurt","cv","Gini","lac")

# Get value of probes of the raw data sets and 100 predicted distributions each
set.seed(123)
probes_d <- probe_dist_list(c(lapply(seq_len(100), function(x){
  predict(field_herb_fit)
}),
list(field_herb_fit$data),
lapply(seq_len(100), function(x){
  predict(lab_herb_fit)
}),
list(lab_herb_fit$data)),
probes = probes) %>%
  cbind("source" = c(rep("field", 101), rep("lab", 101)),
        "type" = rep(c(rep("predicted", 100), "observed"), 2)
  )


## -----------------------------------------------------------------------------
# Reduce the dimension of probes with PCA and plot
vegan::rda(scale(probes_d[,probes])) %>%
  get_biplot(group = probes_d$source,
             group2 = probes_d$type,
             ellipse = "t",
             sites_size = ifelse(probes_d$type == "observed", 5, 2)) +
  ggplot2::scale_shape_manual(values = c(19,2)) + 
  ggplot2::labs(shape = "type", 
       color = "source")

## -----------------------------------------------------------------------------
# Do other test of absolute fit
set.seed(123)
compare_dist_list(list("lab" = lab_herb_fit,
                       "field" = field_herb_fit), 
                  test = c("ks", "kl","ad"), 
                  silent = TRUE)

## -----------------------------------------------------------------------------
x <- seq(0.4,10, by = 0.4)
y <- vapply(x,
       function(x) palloT(0.2, 
                          lambda = x,
                          lower.tail = FALSE), 
       FUN.VALUE = numeric(1))

plot(y~x, 
     ylab = "Pr(Herbivory > 20%)", 
     xlab = expression(Attack~rate~lambda))
graphics::abline(v = 3.3, col = "red") 
graphics::segments(x0 = 0,x1 = 3.3, y0 = 0.3, y1 = 0.3, col = "black", lty = "dashed")


## -----------------------------------------------------------------------------
JE(model = function(x){100 -100*x^4}, 
   x = ralloT(n = 1000, lambda = 3.3), 
   plot = TRUE)


## -----------------------------------------------------------------------------
herbivar.version()
sessionInfo()

